<?php
$conn = mysqli_connect("localhost", "root", "");
$db = mysqli_select_db($conn, 'online');
$id = $_GET['id'];
$cat = $_GET['cat'];
$val = $_GET['val'];
$query = "SELECT * FROM addproduct where productid='$id'";
$data = mysqli_query($conn, $query);
//$total=mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);
$p = $result['minbidamount'];
                   $t=new DateTime();
                   $presentday=date_format($t,"d");
                   $presentmon=date_format($t,"m");
                   
                    $date=date_create($result['auctiontime']);
                    $fetchday=date_format($date,"d");
                    $fetchmon=date_format($date,"m");
                    
                    $resday=$presentday-$fetchday;
                    $resmon=$presentmon-$fetchmon;

?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Update bid amount</title>
  <link rel="stylesheet" href="../selleradd items/style.css" />
  <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
</head>

<body>
  <div class="container">

    <span class="big-circle"></span>
    <img src="img/shape.png" class="square" alt="" />
    <div class="form">
      <div class="contact-info">
        <h3 class="title">Item details</h3>
        <p class="text">
          Please Update the details carefully.
        </p>

        <div class="info">
          <div>

            <a href="../Bidder/Bidder.php?id=<?php echo $cat; ?>&name=<?php echo $val ?>;">
              <input type="submit" value="Dashboard" class="bten"></a>
          </div>
        </div>

      </div>

      <div class="contact-form">
        <span class="circle one"></span>
        <span class="circle two"></span>

        <form action="" method="POST" enctype="multipart/form-data">
          <h3 class="title">Update bid amount</h3>
          <div class="input-container">
            <input type="text" required name="name" value="<?php echo $result['productname']; ?>" class="input" readonly />

          </div>
          <div class="input-container">
            <input type="text" required name="bidamount" value="<?php echo $result['minbidamount']; ?>" class="input" />

          </div>
          <div class="input-container">
            <input type="text" required name="time" value="<?php echo $result['auctiontime']; ?>" class="input" readonly />

          </div>

          <div class="input-container">
            <input type="text" required name="desc" value="<?php echo $result['Description']; ?>" class="input" readonly />

          </div>

          <div class="input-container">
            <input type="text" required name="category" value="<?php echo $result['category']; ?>" class="input" readonly />


          </div>



          <input type="submit" value="Update" name="Update" class="btn" />
        </form>
      </div>
    </div>
  </div>


</body>
<script src="app copy.js"></script>

</html>
<?php
if ($_POST['Update']) {
  if($resday>=0 and $resmon>=0){
    echo '<script type="text/javascript"> alert("Bid is completed")</script>';
  }
  else {
  $amount = $_POST['bidamount'];
  if ($p < $amount) {
    $query = "UPDATE addproduct set minbidamount='$amount' where productid='$id'";
    $query_run = mysqli_query($conn, $query);
    $d = "UPDATE addproduct set lastupdatedid='$val' where productid='$id'";
    $query_run = mysqli_query($conn, $d);
  } else {
    echo '<script type="text/javascript"> alert("Please Enter big amount")</script>';
  }
  if ($query_run) {
    echo '<script type="text/javascript"> alert("Record updated")</script>';
    header("Location:../Bidder/Bidder.php?id=$cat&name=$val");
  } else {
    echo '<script type="text/javascript"> alert("Record not updated")</script>';
  }
}
}

?>