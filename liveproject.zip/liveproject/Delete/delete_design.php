<?php
$conn=mysqli_connect("localhost","root","");
$db=mysqli_select_db($conn,'online');
$id=$_GET['id'];
$cat=$_GET['cat'];
$query="DELETE FROM addproduct where productid='$id'";
$data=mysqli_query($conn,$query);
//$total=mysqli_num_rows($data);
//$result=mysqli_fetch_assoc($data);

if ($data)
{
    echo '<script type="text/javascript"> alert("Record Deleted")</script>';
    ?>
    <meta http-equiv="refresh" content="0; url=http://localhost/liveproject/Delete/delete.php?id=<?php echo $cat?>"/>
    <?php
    }
    else{
    echo '<script type="text/javascript"> alert("Record not Deleted")</script>';
    }

?>

