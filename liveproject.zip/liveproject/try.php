<?php
$id=$_GET['id'];
$val=$_GET['name'];
$pid=$_GET['pid'];


            $conn=mysqli_connect("localhost","root","",'online');
            $query="select * from addproduct where productid=$pid and lastupdatedid=$id";

            $result=mysqli_query($conn,$query);
            //$row=mysqli_num_rows($query_run);
                if($query_run=mysqli_fetch_array($result)){
                    
                   $t=new DateTime();
                   $presentday=date_format($t,"d");
                   $presentmon=date_format($t,"m");
                   
                    $date=date_create($query_run['auctiontime']);
                    $fetchday=date_format($date,"d");
                    $fetchmon=date_format($date,"m");
                    
                    $resday=$presentday-$fetchday;
                    $resmon=$presentmon-$fetchmon;
                    
                    if ($resday>=0 and $resmon>=0){
                      echo '<script type="text/javascript"> alert("You are winner")</script>';?>
                      <meta http-equiv="refresh" content="0; url=http://localhost/liveproject/Bidder/Bidder.php?id=<?php echo $val;?>&name=<?php echo $id;?>"/><?php
                    }
                    else{
                      echo '<script type="text/javascript"> alert("Bidding not completed")</script>';?>
                      <meta http-equiv="refresh" content="0; url=http://localhost/liveproject/Bidder/Bidder.php?id=<?php echo $val;?>&name=<?php echo $id;?>"/><?php
                      exit;
                    }
                    
                    
                    
                    ?><br>
               <?php
              
                }
                else{
                  echo '<script type="text/javascript"> alert("You are not winner")</script>';?>
                  <meta http-equiv="refresh" content="0; url=http://localhost/liveproject/Bidder/Bidder.php?id=<?php echo $val;?>&name=<?php echo $id;?>"/><?php
                }
                ?>