<?php
$conn=mysqli_connect("localhost","root","");
$db=mysqli_select_db($conn,'online');
$id=$_GET['id'];
$query="SELECT * FROM addproduct where productid='$id'";
$data=mysqli_query($conn,$query);
//$total=mysqli_num_rows($data);
$result=mysqli_fetch_assoc($data);

?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Update bid amount</title>
    <link rel="stylesheet" href="../selleradd items/style.css" />
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <div class="container">
      
      <span class="big-circle"></span>
      <img src="img/shape.png" class="square" alt="" />
      <div class="form">
        <div class="contact-info">
          <h3 class="title">Item details</h3>
          <p class="text">
            All the below points are necessary to add the product for auction.
          </p>

          <div class="info">
            <div class="information">
              
              <p>You must have Product name</p>
            </div>
            <div class="information">
              
              <p>Minimum Amount </p>
            </div>
            <div class="information">
              <p>Auction Time</p>
            </div>
            
            <div class="information">
              <p>Description</p>
            </div>

            <div class="information">
              <p>Category</p>
            </div>

            
            <br>
            <br>
            <div>
            
            <a href="../Bidder/Bidder.php">
            <input type="submit"  value="Dashboard" class="bten"></a>
        </div>
          </div>
  
        </div>

        <div class="contact-form">
          <span class="circle one"></span>
          <span class="circle two"></span>

          <form action="" method="POST" enctype="multipart/form-data">
            <h3 class="title">Update bid amount</h3>
            <div class="input-container">
              <input type="text" name="name"  value="<?php echo $result['productname'];?>" class="input" readonly/>
            
            </div>
            <div class="input-container">
              <input type="text" name="bidamount" value="<?php echo $result['minbidamount'];?>" class="input" />
              
            </div>
            <div class="input-container">
              <input type="text" name="time" value="<?php echo $result['auctiontime'];?>" class="input" readonly/>
              
            </div>

            <div class="input-container">
              <input type="text" name="desc" value="<?php echo $result['Description'];?>" class="input" readonly />
              
            </div>

            <div class="input-container">
              <input type="text" name="category" value="<?php echo $result['category'];?>" class="input" readonly/>
              
              
            </div>

           

            <input type="submit" value="Update" name="Update"  class="btn" />
          </form>
        </div>
      </div>
    </div>


  </body><script src="app copy.js"></script>
  </html>
<?php
    if($_POST['Update'])
{
    $amount=$_POST['bidamount'];
    
    $query="UPDATE addproduct set minbidamount='$amount' where productid='$id'";
    $query_run=mysqli_query($conn,$query);

    if ($query_run){
        echo '<script type="text/javascript"> alert("Record updated")</script>';
        header("Location:../Bidder/Bidder.php");
    }
    else{
        echo '<script type="text/javascript"> alert("Record not updated")</script>';
    }

}


?>

