<?php
$name=$_POST['Name'];
$Email=$_POST['Email'];
$Password=$_POST['Password'];
$Number=$_POST['Number'];
$Registered=$_POST['Registered'];

//Database connection
$conn=new mysqli('localhost','root','','online');

if ($conn->connect_error){
    die('Connection Failed: '.$conn->connect_error);
}
else {
    ?>
    <script>
        alert("connection successfull")
        </script>
    <?php
    $stmt = $conn->prepare("insert into signup(Name,Email,Password,Number,Registered) values(?,?,?,?,?)");
    $stmt->bind_param("sssis", $name, $Email, $Password, $Number,$Registered);
    $stmt->execute();
    header('location:loginsignup.html');
    $stmt->close();
    $conn->close();
    
}
?>