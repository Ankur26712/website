<?php
$conn=new mysqli('localhost','root','','online');

if ($_POST['SignIN']){
    $name=$_POST['Name'];
    $pass=$_POST['PASS'];
    $reg=$_POST['Regist'];
    
    $email_search="select * from signup where name='$name' and password='$pass' ";
    $query=mysqli_query($conn,$email_search);
    $email_count=mysqli_num_rows($query);
    $query_run=mysqli_fetch_array($query);
    if ($email_count){
        
        if ($reg=="Admin")
        { ?>

            <script >
            window.location.href="http://localhost/liveproject/adminhomepage/adminhomepage.php?id=<?php echo $query_run['id'];?>";
            </script>
         <?php
    }
    
    elseif ($reg=="Seller")
    { ?>

        <script >
        window.location.href='../sellerhomepage/connect.php?id=<?php echo $query_run['id'];?>&name=<?php echo $query_run['Name'];?>';
        </script>
     <?php
}
    else{
        ?>

        <script >
        window.location.href='../Bidder/Bidder.php?id=<?php echo $query_run['Name'];?>'';
        </script>
     <?php
    }
}

    else
    echo " password error";

}
?>

