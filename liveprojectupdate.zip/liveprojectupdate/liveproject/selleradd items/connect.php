<!DOCTYPE html>
<?php
$id=$_GET['id'];
$name=$_GET['name'];
?>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Upload Product details</title>
    <link rel="stylesheet" href="style.css" />
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <div class="container">
      
      <span class="big-circle"></span>
      <img src="img/shape.png" class="square" alt="" />
      <div class="form">
        <div class="contact-info">
          <h3 class="title">Upload Items</h3>
          <p class="text">
            All the below points are necessary to add the product for auction.
          </p>

          <div class="info">
            <div class="information">
              
              <p>You must have Product name</p>
            </div>
            <div class="information">
              
              <p>Minimum Amount </p>
            </div>
            <div class="information">
              <p>Auction Time</p>
            </div>
            
            <div class="information">
              <p>Description</p>
            </div>

            <div class="information">
              <p>Category</p>
            </div>

            <div class="information">
              <p>Product Image</p>
            </div>
            <br>
            <br>
            <div>
            
            <a href="../sellerhomepage/connect.php?id=<?php echo $id; ?>&name=<?php echo $name; ?>">
            <input type="submit"  value="Dashboard" class="bten"></a>
        </div>
          </div>
  
        </div>

        <div class="contact-form">
          <span class="circle one"></span>
          <span class="circle two"></span>

          <form action="" method="POST" enctype="multipart/form-data">
            <h3 class="title">Add Items</h3>
            <div class="input-container">
              <input type="text" name="name" id="Name"  class="input" />
              <label for="">Enter the Product Name</label>
              <span>Enter the Product Name</span>

            </div>
            <div class="input-container">
              <input type="text" name="miniamount" id ="Minimum Amount" class="input" />
              <label for="">Enter Minimum Amount</label>
              <span>Enter Minimum Amount</span>
            </div>
            <div class="input-container">
              <input type="text" name="auctiontime" id ="auctiontime" class="input" />
              <label for="">Enter Auction time</label>
              <span>Enter Auction time</span>
            </div>

            <div class="input-container">
              <input type="text" name="Description" id ="Description" class="input" />
              <label for="">Enter Description</label>
              <span>Enter Description</span>
            </div>

            <div class="input-container">
              <input type="text" name="category" id ="category" class="input" />
              <label for="">Enter category</label>
              <span>Enter category</span>
            </div>

            <div class="input-container">
              <input type="file" name="image" id ="image" class="input" />
              <label for="">Insert the Image</label>
              <span>Insert the Image</span>
            </div>

            <input type="submit" value="upload" name="upload" class="btn" />
          </form>
        </div>
      </div>
    </div>


  </body><script src="app.js"></script>
</html>


<?php
 
  
    $conn=mysqli_connect("localhost","root","");
    $db=mysqli_select_db($conn,'online');
    
    
    if (isset($_POST['upload']))
    {
        $name=$_POST['name'];
        $amount=$_POST['miniamount'];
        $time=$_POST['auctiontime'];
        $desc=$_POST['Description'];
        $category=$_POST['category'];
        $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));


        $query="INSERT INTO `addproduct` (`id`,`productname`, `minbidamount`, `auctiontime`, `Description`, `category`,`image`) VALUES ( '$id','$name', '$amount', '$time', '$desc', '$category','$file')";
        $query_run=mysqli_query($conn,$query);

        if ($query_run){
            echo '<script type="text/javascript"> alert("Image uploaded")</script>';

        }
        else{
            echo '<script type="text/javascript"> alert("Image  not uploadeduploaded")</script>';
        }

    }
    ?>
