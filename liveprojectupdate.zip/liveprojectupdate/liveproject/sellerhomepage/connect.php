<!DOCTYPE html>
<?php
$id = $_GET['id'];
$name = $_GET['name'];
?>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Seller Dashboard</title>
  <link rel="stylesheet" href="style.css" />
  <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</head>

<body>
  <header>
    <div class="container pt-2">
      <div class="logo-container">
        <div class="logo img"><img src="./logo.png"> </div>
        <h3 class="logo img">E<span>Auction</span></h3>

      </div>

      <div align="right">

        <! –– link for the logout is to be inserted here ––>
        <span class="pr-2" style="color:white;"><?php echo $name ?></span>
          <a href="../logout.php">
            <input type="submit" value="LOGOUT" class="bten"></a>
      </div>

    </div>
  </header>



  <div class="container-fluid p-0">
    <main class="row pt-4 m-0">
      <div class="col-3 ml-2" style="background-color:#ff8c6b;height: 300px;">

        <div class="p-3 pt-5" style="text-align:center">
          <a href="../selleradd items/connect.php?id=<?php echo $id; ?>&name=<?php echo $name; ?>">
            <input type="submit" value="     Add Product    " class="bten"></a>
        </div>

        <div class="p-3" style="text-align:center">
          <a href="../Delete/delete.php?id=<?php echo $id;?>" style="display:inline-block">
            <input type="submit" value="    Delete Product    " class="bten"></a>
        </div>
      </div>


      <div class="col">
        <table class="table" style="background-color:#ff8c6b">
          <form method="POST" enctype="multipart/form-data">
            <tr>
              <th>Product Name</th>
              <th>Amount</th>
              <th>Auction Time</th>
              <th>Description</th>
              <th>Category</th>
              <th>Image</th>

            </tr>
            <tr>
              <?php


              $conn = mysqli_connect("localhost", "root", "", 'online');
              $query = "select * from addproduct where id='$id'";
              $result = mysqli_query($conn, $query);
              //$row=mysqli_num_rows($query_run);
              while ($query_run = mysqli_fetch_array($result)) {

              ?>
            <tr>
              <td><?php echo $query_run['productname']; ?></td>
              <td><?php echo $query_run['minbidamount']; ?></td>
              <td><?php echo $query_run['auctiontime']; ?></td>
              <td><?php echo $query_run['Description']; ?></td>
              <td><?php echo $query_run['category']; ?></td>
              <td><?php echo '<img src="data:image;base64,' . base64_encode($query_run['image']) . '" alt="Image" width=50px;>'; ?></td>

            </tr>
          <?php
              }
          ?>
          </tr>
          </form>
        </table>

      </div>
    </main>
  </div>
  <!-- Javascript file -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="app.js"></script>
</body>

</html>