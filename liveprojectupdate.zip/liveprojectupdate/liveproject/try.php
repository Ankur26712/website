<?php
echo "welcome";
$servername="localhost";
$username="root";
$password="";
$conn=mysqli_connect($servername,$username,$password,);
if ($conn){
    echo "this is me";
}
echo "hello";
?>