<?php
session_start();
if (!isset( $_SESSION['logged'])|| $_SESSION['logged']!=true){?>
  <script>
  window.location.href='../loginsignup/loginsignup.html';
  </script>
  <?php
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <style>
      h4 {text-align: center;
      font-size:20px;}


    </style>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Member Details</title>
    <link rel="stylesheet" href="style.css" />
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
    
  </head>
  <body>
    <header>
  <div class="container">
            <div class="logo-container">
            <div class="logo img"><img src="./logo.png"> </div>
                <h3 class="logo img">E<span>Auction</span></h3> 
                
            </div>

            <div align="right">

            <! –– link for the logout is to be inserted here ––>
          <a href="../logout.php">
            <input type="submit"  value="LOGOUT"  class="bten"></a>
        </div>
                
     </div>

            <h4> MEMBER DETAILS</h4>


</header>
    <main>
      <form  method="POST" >
       <table  class="box" width="100%" > 
           
        <tr >
            <th>NAME </th>
            <th>EMAILID</th>
            <th >PHONE NUMBER</th>
            <th>REGISTERED</th>
            <th>Operation</th>
            
            

        </tr>
        
            <?php
            $conn=mysqli_connect("localhost","root","",'online');
            $query="select * from signup where Registered in('Seller','Bidder')";
            $result=mysqli_query($conn,$query);
            //$row=mysqli_num_rows($query_run);
                while($query_run=mysqli_fetch_array($result)){

               ?>
               <tr>
                    <td><?php echo $query_run['Name'];?></td>
                    <td><?php echo $query_run['Email'];?></td>
                    <td><?php echo $query_run['Number'];?></td>
                    <td><?php echo $query_run['Registered'];?></td>
                    <td><a href='delete_design.php?id=<?php echo $query_run['id'];?>'onclick='return checkdelete()'>Delete entry</a></td>
                    <!--This is a comment. insert link for the bid winner of this product -->

                    
              </tr>
              <?php
            }
            ?>
              </tr>
          </table>
          </form> 
          
    </main>
   
    <!-- Javascript file -->
    <script>
      
    function checkdelete()
    {
      return confirm('Are you sure you want to delete this record');
    } </script>
    <script src="app.js"></script>
  </body>
</html>
