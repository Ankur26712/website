<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contact Form</title>
    <link rel="stylesheet" href="style.css" />
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <div class="container">
      <span class="big-circle"></span>
      <img src="img/shape.png" class="square" alt="" />
      <div class="form">
        <div class="contact-info">
          <h3 class="title">Let's get in touch</h3>
          <p class="text">
            We are ready to take your suggestions so that we can upgrade our website and deliver best services.
          </p>

          <div class="info">
            <div class="information">
              <img src="img/location.png" class="icon" alt="" />
              <p>PSIT Kanpur-Agra - Delhi, NH2, Bhauti, Kanpur, Uttar Pradesh 209305</p>
            </div>
            <div class="information">
              <img src="img/email.png" class="icon" alt="" />
              <p>psit@gmail.com</p>
            </div>
            <div class="information">
              <img src="img/phone.png" class="icon" alt="" />
              <p>123456789</p>
            </div>
          </div>

          <div class="social-media">
            <p>Connect with us :</p>
            <div class="social-icons">
              <a href="https://www.facebook.com/aditya.singham.921">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a href="https://mobile.twitter.com/adityasingh6789">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="https://www.instagram.com/_adityarajawat/">
                <i class="fab fa-instagram"></i>
              </a>
              <a href="https://www.linkedin.com/in/aditya-singh-bb31a0200">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>
        </div>

        <div class="contact-form">
          <span class="circle one"></span>
          <span class="circle two"></span>

          <form action="" method="POST" enctype="multipart/form-data">
            <h3 class="title">Contact us</h3>
            <div class="input-container">
              <input type="text" name="name" id="name" class="input" />
              <label for="">Username</label>
              <span>Username</span>
            </div>
            <div class="input-container">
              <input type="email" name="email" id="email" class="input" />
              <label for="">Email</label>
              <span>Email</span>
            </div>
            <div class="input-container">
              <input type="tel" name="phone" id="phone" class="input" />
              <label for="">Phone</label>
              <span>Phone</span>
            </div>
            <div class="input-container textarea">
              <textarea name="message" class="input"></textarea>
              <label for="">Message</label>
              <span>Message</span>
            </div>
            <input type="submit" value="Send" name="Send" class="btn" />
          </form>
        </div>
      </div>
    </div>

    <script src="app.js"></script>
  </body>
</html>
<?php
    $conn=mysqli_connect("localhost","root","");
    $db=mysqli_select_db($conn,'online');
    
    if (isset($_POST['Send']))
    {
        $name=$_POST['name'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
        $message=$_POST['message'];
        


        $query="INSERT INTO `contactus` (`Username`, `Email`, `Phone`, `Message`) VALUES ('$name', '$email', '$phone', '$message')";
        $query_run=mysqli_query($conn,$query);

        if ($query_run){
            echo '<script type="text/javascript"> alert("Data Send")</script>';

        }
        else{
            echo '<script type="text/javascript"> alert("Data not uploaded")</script>';
        }

    }
  ?>