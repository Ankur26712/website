<?php
$conn=new mysqli('localhost','root','','online');

if ($_POST['SignIN']){
    $name=$_POST['Name'];
    $pass=$_POST['PASS'];
    $reg=$_POST['Regist'];
    
    $email_search="select * from signup where name='$name' and password='$pass' ";
    $query=mysqli_query($conn,$email_search);
    $email_count=mysqli_num_rows($query);
    $query_run=mysqli_fetch_array($query);
    if ($email_count){
        
        if ($reg=="Admin")
        {
            session_start();
        $_SESSION['logged']=true;
        $_SESSION['username']=$name;
           ?>

            <script >
            window.location.href="http://localhost/liveproject/adminhomepage/adminhomepage.php?id=<?php echo $query_run['id'];?>";
            </script>
         <?php
    }
    
    elseif ($reg=="Seller")
    {
        session_start();
        $_SESSION['logged']=true;
        $_SESSION['username']=$name;
 ?>

        <script >
        window.location.href='../sellerhomepage/connect.php?id=<?php echo $query_run['id'];?>&name=<?php echo $query_run['Name'];?>';
        </script>
     <?php
}
    else{
        session_start();
        $_SESSION['logged']=true;
        $_SESSION['username']=$name;

        ?>

        <script >
        window.location.href='../Bidder/Bidder.php?id=<?php echo $query_run['Name'];?>&name=<?php echo $query_run['id'];?>';
        </script>
     <?php
    }
}

    else{
    echo '<script type="text/javascript"> alert("Record not updated")</script>';
    header('location:loginsignup.html');
}

}
?>

