
<?php
            $conn=mysqli_connect("localhost","root","",'online');
            $query="select * from addproduct";
            $result=mysqli_query($conn,$query);
            //$row=mysqli_num_rows($query_run);
                while($query_run=mysqli_fetch_array($result)){
                    $from=new DateTime($query_run['auctiontime']);
                    $t=new DateTime();
                    $w=date_diff($t,$from)->format("%a");
                    if($w==0){
                        
                    }
                    
                    
                    
                    ?><br>
               <?php
              
                }
                ?>